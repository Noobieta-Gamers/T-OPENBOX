#!/bin/sh

rofi -no-lazy-grab -show drun -theme themes/run.rasi

